#!/bin/bash

make
./index resource/words.txt
make clear