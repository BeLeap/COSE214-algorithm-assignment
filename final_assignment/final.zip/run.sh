#!/bin/bash

make
./index resource/words.txt resource/dist
make clear